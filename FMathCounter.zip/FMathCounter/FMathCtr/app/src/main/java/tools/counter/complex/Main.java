package tools.counter.complex;

import java.util.*;
import android.widget.EditText;

public class Main
{
    EditText e1,e2;
    Out output;
    dw w;
    
    public Main(EditText e1,EditText e2,Out output){
        this.e1=e1;
        this.e2=e2;
        this.output=output;
        this.w=new dw();
    }
    
    public void run() //类的函数 
    {
        output.println("run");
        try{
            Sceners s = new Sceners(new String[3]);
            //if ((s.str[0]=e1.getText().toString()).length()<5) {return;}
            //if ((s.str[1]=e2.getText().toString()).length()<5) {return;}
            s.str[0]=e1.getText().toString();
            s.str[1]=e2.getText().toString();
            s.str[2]="+";
            output.println(s.str[0]+" "+s.str[2]+" "+s.str[1]);
            w.shell(s,output);
            s.resetL();
            s.str[2]="-";
            output.println(s.str[0]+" "+s.str[2]+" "+s.str[1]);
            w.shell(s,output);
            s.resetL();
            s.str[2]="*";
            output.println(s.str[0]+" "+s.str[2]+" "+s.str[1]);
            w.shell(s,output);
            s.resetL();
            s.str[2]="/";
            output.println(s.str[0]+" "+s.str[2]+" "+s.str[1]);
            w.shell(s,output);
            s.resetL();
            s.str[2]="!";
            output.println(s.str[0]+" "+s.str[2]+" "+s.str[1]);
            w.shell(s,output);
        
        }
        catch (Throwable T) {output.println(T);}
    }
    static class dw
    {
        Complex A;
        Complex B;
        Complex R;
        Complex F;
        boolean printF;
        public Complex shell(Sceners s,Out out){
            out.println("复数A :");
            String a;
            a=s.next();
            A = Complex.readString(a);
            out.println("复数B :");
            String b;
            b=s.next();
            B = Complex.readString(b);
            out.println("执行操作 :");
            switch(s.next().toCharArray()[0])
            {
                case '+' : R=Complex.pushApB(A,B); break;
                case '-' : R=Complex.cutAcB(A,B); break;
                case 'x' : R=Complex.AmB(A,B); break;
                case '÷' : F=Complex.AdB(A,B);printF=true; break;
                case '*' : R=Complex.AmB(A,B);printF=true; break;
                case '/' : F=Complex.AdB(A,B); break;
                case '!' : R=Complex.Af(A); break;
            }
            out.println("结果"+R.toString());
            if(F!=null&&printF)
            {
                out.print("得出"+F.toString());
                printF=false;
            }
            return R;
        }
    }
}
class Complex    //定义类
{
    public double x,y;
    public Complex(double x,double y){
        this.x=x;
        this.y=y;
    }

    @Override
    public String toString()
    {
        return x+"+"+y+"i";
    }

    public static Complex readString(String str){
        double x,y;
        char[] cr=str.toCharArray();
        int i=0,l=cr.length;
        int wp=0;
        while(i<l){
            if(cr[i]=='+') wp=i;
            if(cr[i]=='-') wp=i;
            i++;
        }
        char[] xcr=Arrays.copyOfRange(cr,0,wp-0);
        char[] ycr=Arrays.copyOfRange(cr,wp,cr.length-1);
        x=Double.valueOf(String.valueOf(xcr));
        y=Double.valueOf(String.valueOf(ycr));
        return new Complex(x,y);
    }
    public static Complex pushApB(Complex A,Complex B){
        return new Complex(A.x+B.x,A.y+B.y);
    }
    public static Complex cutAcB(Complex A,Complex B){
        return new Complex(A.x-B.x,A.y-B.y);
    }
    public static Complex AmB(Complex A,Complex B){
        double p1=(A.x*B.x)-(A.y*B.y);
        double p2=(A.x*B.y)+(A.y*B.x);
        return new Complex(p1,p2);
    }
    public static ComplexFraction AdB(Complex A,Complex B){
        Complex p1=AmB(A,Af(B));
        double p2=(B.x*B.x)+(B.y*B.y);
        return new ComplexFraction(p1.x,p1.y,p2);
    }
    public static Complex Af(Complex F){
        return new Complex(F.x,-F.y);
    }
}
class ComplexFraction extends Complex
{
    double dividend;
    public ComplexFraction (double x,double y,double dividend) {
        super(x,y);
        this.dividend=dividend;
    }

    @Override
    public String toString()
    {
        return super.toString()+"/"+Double.toString(dividend);
    }
    public static Complex runFinish(ComplexFraction A){
        return new Complex(A.x/A.dividend,A.y/A.dividend);
    }
}
