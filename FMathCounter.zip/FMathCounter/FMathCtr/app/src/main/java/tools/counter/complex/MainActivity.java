package tools.counter.complex;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.view.View;

public class MainActivity extends Activity {
EditText e1,e2,e3;
Button b1;
Main m;
Out o;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Object oe1=findViewById(R.id.e1);
        Object oe2=findViewById(R.id.e2);
        Object oe3=findViewById(R.id.e3);
        Object ob1=findViewById(R.id.b1);
        if(oe1 instanceof EditText)
            e1=(EditText)oe1;
        if(oe2 instanceof EditText)
            e2=(EditText)oe2;
        if(oe3 instanceof EditText)
            e3=(EditText)oe3;
        if(ob1 instanceof Button)
            b1=(Button)ob1;
        o=new Out(e3);
        m=new Main(e1,e2,o);
        b1.setOnClickListener(
        new OnClickListener()
            {

                @Override
                public void onClick(View p1)
                {
                    m.run();
                }
            
        }
        );
    }
    
}
class Sceners{
    public String str[];
    public int l;
    public Sceners(String[] strs)
    {
        this.str=strs;
        this.l=0;
    }
    public String next()
    {
        if (l<str.length)
            {
            l++;
            return str[l-1];
        }
        return null;
    }
    public void resetL()
    {
        l=0;
    }
}
class Out{
    public Out (TextView t1) {
        this.t1=t1;
    }
    TextView t1;
    public void println(Object obj){
        output(obj.toString()+"\n");
    }
    public void print(Object obj){
        output(obj.toString());
    }
    private void output(String str){
        t1.setText(t1.getText()+str);
    }
}
